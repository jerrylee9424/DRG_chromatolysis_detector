"""The content of torch/testing/_dtype_getters.py should be moved here as soon as the deprecation period is over.
"""

from torch.testing._dtype_getters import *  # noqa: F401, F403
