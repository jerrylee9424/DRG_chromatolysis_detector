import torch  # noqa: F401


def div_int_nofuture():
    return 1 / 2


def div_float_nofuture():
    return 3.14 / 0.125
